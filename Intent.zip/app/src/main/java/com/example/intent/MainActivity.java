package com.example.intent;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button explicitintent;
    ImageButton yt;
    ImageButton ig;
    ImageButton fb;
    ImageButton tt;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        explicitintent = (Button) findViewById(R.id.explicitintent);
        explicitintent.setOnClickListener(this);
        yt = (ImageButton) findViewById(R.id.yt);
        yt.setOnClickListener(this);
        ig = (ImageButton) findViewById(R.id.ig);
        ig.setOnClickListener(this);
        fb = (ImageButton) findViewById(R.id.fb);
        fb.setOnClickListener(this);
        tt = (ImageButton) findViewById(R.id.tt);
        tt.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.explicitintent:
                Intent explicit = new Intent(MainActivity.this, IntentActivity.class);
                startActivity(explicit);
                break;
            case R.id.yt:
                Intent yts = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com"));
                startActivity(yts);
                break;
            case R.id.ig:
                Intent igs = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.instagram.com"));
                startActivity(igs);
                break;
            case R.id.fb:
                Intent fbs = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.facebook.com"));
                startActivity(fbs);
                break;
            case R.id.tt:
                Intent tts = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.tiktok.com"));
                startActivity(tts);
                break;
            default:
                break;
        }
    }
}
