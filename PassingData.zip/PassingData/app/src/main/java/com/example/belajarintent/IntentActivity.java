package com.example.belajarintent;

public class IntentActivity {
}
